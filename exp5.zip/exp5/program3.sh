echo "enter a number:"
read num
i=1
while [ $i -le 10 ]
do
if [ $((i % 2)) -eq 0 ]
then 
echo "even:$i"
else echo "odd:$i"
fi
i=$((i+1))
done

