i=2
sum=0
while [ $i -le 10 ]
do
sum=$((sum+i))
i=$((i+2))
done
echo "sum:$sum"
