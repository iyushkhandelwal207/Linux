echo "enter your name:"
read name
echo "enter three marks:"
read a b c
echo "name :$name"
total=$((a+b+c))
avg=$((total/3))
if [ $avg -gt 90 ]
then 
echo "A"
elif [ $avg -le 90 ] && [ $avg -gt 80 ]
then 
echo "B"
elif [ $avg -le 80 ] && [ $avg -gt 70 ]
then 
echo "C"
elif [ $avg -le 70 ] && [ $avg -gt 55 ]
then 
echo "D"
elif [ $avg -le 55 ] && [ $avg -gt 40 ]
then 
echo "E"
else echo "fail"
fi

