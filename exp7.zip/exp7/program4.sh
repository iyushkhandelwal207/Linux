i=1
while [ $i -lt 5 ]
do
echo "1.additon 2.substraction 3.multiply 4.division 5.exit"
read i
echo "enter two number:"
read a b
case $i in
1)echo "$((a+b))" ;;
2)echo "$((a-b))" ;;
3)echo "$((a*b))" ;;
4)echo "$((a/b))" ;;
*)echo "exiting............" ;;
esac
done

