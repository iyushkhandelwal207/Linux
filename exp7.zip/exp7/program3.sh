echo "enter two number:"
read a b
if [ $a -gt $b ]
then 
echo "b is smallest:$b"
elif [ $a -eq $b ]
then 
echo "both are equal:$a"
else echo "a is smallest:$a"
fi

