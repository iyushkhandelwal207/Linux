echo "enter a number:"
read num
sum=0
while [ $num -ne 0 ]
do
remainder=$((num%10))
sum=$((sum+remainder*remainder*remainder))
num=$((num/10))
done
echo "sum:$sum"
