declare -a my
echo "enter no of elements you want to insert:"
read num
sum=0
for((i=0;i<num;i++))
do
echo "enter $((i+1)) element"
read element
my[$i]=$element
done
echo "element in array:"
for element in "${my[@]}"
do
        echo "$element"
   sum=$((sum+$element))
done
echo "sum:$sum"


