echo "enter number:"
read n
a=0
b=1
d=0
c=0
echo "$a"
echo "$b"
while [ $c -le $n ]
do
c=$((a+b))
a=$b
b=$c
#d=$d+1
echo "$c ";
done 
