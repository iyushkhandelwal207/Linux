echo "enter num"
read num
n=$num
a=0
while [ $num -gt 0 ]
do
remainder=$((num%10))
a=$((a+remainder*remainder*remainder))
num=$((num/10))
done
if [ $a -eq $n ]
then
        echo "armstrong number"
else echo "not armstrong number"
fi

