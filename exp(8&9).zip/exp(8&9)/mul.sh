declare -a a
declare -a b
declare -a c
echo "enter no of rows :"
read num
sum=0
echo "enter element in 1 matrix:"
for((i=0;i<num;i++))
do
        for((j=0;j<num;j++))
        do
                echo "enter $((i+1)),$((j+1)) element"
                read -p "a[$i][$j]:" a["$i$j"]
               # my[$i][$j]=$element
        done
done
echo "enter element in 2 matrix:"
for((i=0;i<num;i++))
do
        for((j=0;j<num;j++))
        do
                echo "enter $((i+1)),$((j+1)) element"
                read -p "b[$i][$j]:" b["$i$j"]
               # my[$i][$j]=$element
        done
done
for((i=0;i<num;i++))
do
        for((j=0;j<num;j++))
        do
                for((k=0;k<num;k++))
                do
                    c["$i$j"]=$((c["$i$j"]+a["$i$k"]*b["$k$j"]))
                done
               # my[$i][$j]=$element
        done
done
echo "multiply:"
for((i=0;i<num;i++))
do
        for((j=0;j<num;j++))
        do
               echo -n "${c["$i$j"]} "
               # my[$i][$j]=$element
        done
        echo ""
done

